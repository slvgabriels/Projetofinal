<h3><a class="btn btn-primary" href="?pg=cadastra_pagina">Cadastrar nova página</a></h3>
<h2>Lista de páginas do site</h2>
<table class="table table-striped">
    <thead>
    <tr>
        <th>Página</th>
        <th>Descrição</th>
        <th>URL</th>
        <th>Opções</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>Quem Somos</td>
        <td>Dados sobre a empresa</td>
        <td>quemsomos</td>
        <td><a href="?pg=editar_pagina">Editar </a>| Excluir</td>
    </tr>
    <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
    </tr>
    <tr>
        <td>July</td>
        <td>Dooley</td>
        <td>july@example.com</td>
    </tr>

    </tbody>
</table>
