<?php

    echo "<h2>Bem-vindo ao painel principal!</h2>";

?>