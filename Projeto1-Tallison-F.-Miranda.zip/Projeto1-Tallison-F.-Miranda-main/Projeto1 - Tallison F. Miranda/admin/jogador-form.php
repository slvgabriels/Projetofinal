<h2>Cadastro de Jogadores</h2>
<form action="?pg=jogador-cadastro" method="post">
    <label>Nome:</label>
    <input type="text" name="jogador" required><br>
    <label>Personagem:</label>
    <input type="text" name="personagem"><br>

    <input type="submit" value="Cadastrar cliente">
</form>