<div class="mt-4 p-5 bg-primary text-white rounded">
    <h1>Mapa do site</h1>
    <?php
        include "menu.php";
    ?>
</div>