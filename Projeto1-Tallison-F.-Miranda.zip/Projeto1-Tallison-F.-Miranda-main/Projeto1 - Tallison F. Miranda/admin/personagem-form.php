<h2>Cadastro de Personagens</h2>
<form action="?pg=personagem-cadastro" method="post">
    <label>Nome:</label>
    <input type="text" name="personagem" required><br>
    <label>Jogador:</label>
    <input type="text" name="jogador"><br>
    <label>Espécie:</label>
    <input type="text" name="especie"><br>]
    <label>Classe:</label>
    <input type="text" name="classe"><br>
    <label>Sub-classe:</label>
    <input type="text" name="subclasse"><br>

    <input type="submit" value="Cadastrar personagem">
</form>