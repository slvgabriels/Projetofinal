<?php

    echo "<h2>QUEM SOMOS</h2>";