<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="?pg=conteudo"> Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=quemsomos"> Quem somos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link"  href="?pg=jogadores"> Jogadores</a>
            </li>
            <li class="nav-item">
                <a class="nav-link"  href="?pg=personagens"> Personagens</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?pg=faleconosco"> Contato</a>
            </li>
        </ul>
    </div>
</nav>

